
#include "pch.h"


// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    //Empties the collection
    ASSERT_TRUE(collection->empty());
    //asserts that the size and 0 are equal
    ASSERT_EQ(collection->size(), 0);
    //adds an entry
    add_entries(1);
    //it's no longer true that the collection is empty
    ASSERT_FALSE(collection->empty());
    //asserts that the size and 1 are equal 
    ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
//similar process as the last one
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0);
    add_entries(5);
    ASSERT_FALSE(collection->empty());
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxIsGreaterOrEqual)
{
    //adds the entries
    add_entries(11);
    //checks if the collection's max_size is greater than or equal to 0.. and so on
    ASSERT_TRUE(collection->max_size() >= 0);
    ASSERT_TRUE(collection->max_size() >= 1);
    ASSERT_TRUE(collection->max_size() >= 5);
    ASSERT_TRUE(collection->max_size() >= 10);

}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
//similar logic to the last, just with capacity()
TEST_F(CollectionTest, CapacityIsGreaterOrEqual)
{
    add_entries(11);
    ASSERT_TRUE(collection->capacity() >= 0);
    ASSERT_TRUE(collection->capacity() >= 1);
    ASSERT_TRUE(collection->capacity() >= 5);
    ASSERT_TRUE(collection->capacity() >= 10);
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreases)
{
    //adds entries
    add_entries(1);
    // creates a variable called previousSize and sets it equal to the collections size
    int previousSize = collection->size();
    //resizes the collection
    collection->resize(20);
    //checks to see if the new size is now greater than the previousSize
    ASSERT_TRUE(collection->size() > previousSize);
}

// TODO: Create a test to verify resizing decreases the collection
//similar logic to the last, just reversed
TEST_F(CollectionTest, ResizeDecreases)
{
    add_entries(20);
    int previousSize = collection->size();
    collection->resize(1);
    ASSERT_TRUE(collection->size() < previousSize);
}

// TODO: Create a test to verify resizing decreases the collection to zero
//also similar, just set to zero now
TEST_F(CollectionTest, ResizeToZero)
{
    add_entries(20);
    int previousSize = collection->size();
    collection->resize(0);
    ASSERT_TRUE(collection->size() == 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClear)
{
    //adds entries
    add_entries(20);
    //clears entries
    collection->clear();
    //checks to see if the size is now cleared (zero)
    ASSERT_TRUE(collection->size() == 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
//similar logic to the last one, just using erase(begin, end) now
TEST_F(CollectionTest, VerifyErase)
{
    add_entries(20);
    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->size() == 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreases)
{
    //adds entries
    add_entries(20);
    //creates two variables equal to the previous capacity and size
    int previousCapacity = collection->capacity();
    int previousSize = collection->size();

    //reserve 30 onto the collection
    collection->reserve(30);

    //checks to see if the capacity is greater now, but not the previous size
    ASSERT_TRUE(collection->capacity() > previousCapacity);
    ASSERT_TRUE(collection->size() == previousSize);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, OutOfRange) {
    //creates a vector of 10
    std::vector<int> myvector(10);
    //throws out_of_range if vector is at 20.. negative
    EXPECT_THROW(myvector.at(20), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
//POSITIVE TEST: This one adds one element with a value of 5 using push_back and checks to see if it was added
TEST_F(CollectionTest, PushBack) {
    //adds entries
    add_entries(10);
    //pushes back entries with 1 value of 5
    collection->push_back(5);
    //checks to see if it worked
    ASSERT_TRUE(collection->size() > 10);
}
//NEGATIVE TEST: This one REMOVES an element and tries to see if it's still greater than 10
//(similar logic to the first custom test)
TEST_F(CollectionTest, PopBack) {
    add_entries(10);
    collection->pop_back();
    ASSERT_TRUE(collection->size() > 10);
}
